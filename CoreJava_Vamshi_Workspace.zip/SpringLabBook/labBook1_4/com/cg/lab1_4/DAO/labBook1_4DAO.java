package com.cg.lab1_4.DAO;

import org.springframework.stereotype.Component;

import com.cg.lab1_4.dto.labBook1_4DTO;

//@Component("dao")
public interface labBook1_4DAO {

	labBook1_4DTO getEmp(int id);

}

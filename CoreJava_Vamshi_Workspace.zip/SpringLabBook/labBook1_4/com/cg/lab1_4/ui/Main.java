package com.cg.lab1_4.ui;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.lab1_4.service.labBook1_4Service;

//@Component
//@ComponentScan
public class Main {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		ApplicationContext app = new ClassPathXmlApplicationContext("beans.xml");
		labBook1_4Service service = app.getBean(labBook1_4Service.class);
		
		System.out.print("Enter Employee ID: ");
		int id = sc.nextInt();
		System.out.println(service.getEmp(id));
		
		sc.close();
		
	}
	
}

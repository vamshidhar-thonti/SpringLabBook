package labBook1_1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class labBook1_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
		Employee e = (Employee) app.getBean("emp");
		System.out.println("Employee Details\n---------------------------");
		System.out.println(e);
		
	}

}


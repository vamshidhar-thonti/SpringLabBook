package labBook1_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SBU implements GetsAndSets {
	
	String sbuCode;
	String sbuName;
	String sbuHead;
	
	@Override
	public void setSbuCode(String sbuCode) {
		// TODO Auto-generated method stub
		this.sbuCode = sbuCode;
		
	}
	@Override
	public void setSbuName(String sbuName) {
		// TODO Auto-generated method stub
		this.sbuName = sbuName;
		
	}
	@Override
	public void setSbuHead(String sbuHead) {
		// TODO Auto-generated method stub
		this.sbuHead = sbuHead;
		
	}
	@Override
	public String getSbuCode() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getSbuName() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String getSbuHead() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName
				+ ", sbuHead=" + sbuHead + "]";
	}
	
	

}
